
We have a distributed engineering team working remotely in different countries, effective collaboration and communication is critical.  Therefore, we are looking for engineers who are able to work with remote teams and able to deliver quality product across different time zones and geographical locations.

Here we have 4 case studies arranged in two groups involving different level of difficulties and skill sets.  Please feel free to select two or more cases best illustrate your core competencies.

Some suggestions:
machine learning engineer: (A2, B2) or (A1, B1) or ...
data scientist: (A1, B1) or (A1, A2) or ...
data analyst: (A2, B1) or ...
data engineer: (B1, B2) or ...

We are looking for 5 main areas of your work.
1. Software engineering skills
2. Data engineering skills
3. Data analysis skills
4. Data science skills
5. Research skills

+------------------------------------------------------+
| Challenge A1: Building Model                         |
+------------------------------------------------------+

We have two tab-delimited files:

#### Python code 

    - train.tsv: 5,000 records x 254 features + 1 target (~18.0MB)
    - test.tsv : 1,000 records x 254 features            (~ 3.6MB)

These two synthetic datasets were generated using the same model. We would like you to build a predictive model using the data in the training dataset to predict the hold out target values from the test set.

Please provide your prediction as a 1,000 x 1 test file containing 1 prediction per line for each record in the test dataset.  The accuracy of the prediction will be measured by RMSE.

Again, your remote fellow engineers will be very interested to learn from your research, math, theories, and techniques you use, and eager to discuss this with you face-to-face.

+------------------------------------------------------+
| Challenge A2: Implement a Clustering Algorithm       |
+------------------------------------------------------+

Some engineer suspects the following data points is coming out from 3 clusters.  Can you help him to implement a simple clustering algorithm to find 3 clusters on the following data points.  Please use any common programming languages of your choice.

(1.0, 1.0), (1.5, 2.0), (3.0, 4.0), (5.0, 7.0), (3.5, 5.0), (4.5, 5.0), (3.5, 4.5);

+------------------------------------------------------+
| Challenge B1: Analysis baby name popularity in USA   |
+------------------------------------------------------+

Baby name popularity provided by the Social Security Administration can be downloaded from http://www.ssa.gov/oact/babynames/state/namesbystate.zip.
# Do in R

A) Descriptive analysis

1.  Please describe the format of the data files. Can you identify any
    limitations or distortions of the data?
2.  What is the most popular name of all time? (Of either gender.)
3.  What is the most gender ambiguous name in 2013? 1945?
4.  Of the names represented in the data, find the name that has had the largest
    percentage increase in popularity since 1980. Largest decrease?
5.  Can you identify names that may have had an even larger increase or decrease
    in popularity?

B) Insights!

Besides the analysis above, do you discovery any interesting insights from the dataset?  This is an open ended question.  Please feel free to use your creativity or choices to help us to understand the data better.

If you do not have time to implement your idea, a detailed, actionable
description of how you would address the issue would also help our fellow engineers.

+------------------------------------------------------+
| Challenge B2: Log Processing                         |
+------------------------------------------------------+

#### ask sayan for the code : how to handle the different schema in pyspark and also for multiprocessing
#### save the data in bigplay and work on pyspark for this 
#### Try to do this by today or tomorrow


Our product managers are looking for some basic statistics based on log file

      - web.log: 127 records

They are familiar with the output in the following format

-- Result Codes (most frequent to least) --
200 (Success) - 256 occurrences
403 (Unauthorized) - 10 occurrences
205 (Reset content) - 8 occurrences

-- Sources (most frequent to least) --
64.242.88.10 - 100 occurrences
lj1036.inktomisearch.com - 20 occurrences

-- Bytes Distribution (percentiles) --
25th Percentile: 124
50th Percentile:  3518
75th Percentile: 93593

They will apply your solution to create a daily dashboard from a terabyte of log file in order to make business decision.  So both product and engineering teams are looking for a solution with the following characteristics.

● Scalability: solution should be able to scale to handle continuous streaming of peta-byte of data daily
● Correctness: solution should be able to work and gracefully handle errors
● Readability and maintainability: code readable and extensible
● Trade-offs or related issues made in the solution.
