import os

import luigi

from tasks import Path


class Dataset(luigi.ExternalTask):
    path = luigi.parameter.Parameter(significant=False, description='Dataset location')
    filename = 'train.csv'
    # date columns format:
    #   [{'name': 'name of column with date', 'format': 'string format for parsing date, as in http://strftime.org/'}]
    date_columns = []
    ignore_columns = []

    def extract_dataset_config(self):
        return {
            'target': self.target,
            'date_columns': tuple(self.date_columns),
            'ignore_columns': tuple(self.ignore_columns)
        }

    def extract_path_config(self):
        return {
            'dataset_path': self.path,
            'dataset_filename': self.filename,
            'dataset_name': self.dataset_name
        }

    def output(self):
        out_path = Path(self.extract_path_config()).get_raw_data_path()
        return luigi.LocalTarget(os.path.join(out_path, self.filename))
        # return luigi.LocalTarget(os.path.join(
        #     self.path,
        #     'raw',
        #     self.dataset_name,
        #     self.filename))


class BostonDataset(Dataset):
    filename = 'train.csv'
    dataset_name = 'boston'
    target = 'income'
    date_columns = []
    ignore_columns = []
