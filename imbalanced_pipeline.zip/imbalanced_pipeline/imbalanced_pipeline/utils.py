import json

import luigi
from luigi import task_register


class ListTaskParameter(luigi.parameter.Parameter):
    """
    A parameter that takes another luigi task class.

    When used programatically, the parameter should be specified
    directly with the :py:class:`luigi.task.Task` (sub) class. Like
    ``MyMetaTask(my_task_param=my_tasks.MyTask)``. On the command line,
    you specify the :py:attr:`luigi.task.Task.task_family`. Like

    .. code-block:: console

            $ luigi --module my_tasks MyMetaTask --my_task_param my_namespace.MyTask

    Where ``my_namespace.MyTask`` is defined in the ``my_tasks`` python module.

    When the :py:class:`luigi.task.Task` class is instantiated to an object.
    The value will always be a task class (and not a string).
    """

    def normalize(self, x):
        """
        Ensure that list parameter is converted to a tuple so it can be hashed.

        :param str x: the value to parse.
        :return: the normalized (hashable/immutable) value.
        """
        return tuple(x)

    def parse(self, input):
        """
        Parse a task_famly using the :class:`~luigi.task_register.Register`
        """
        return [task_register.Register.get_task_cls(cls_name) for cls_name in list(json.loads(input))]

    def serialize(self, cls_list):
        """
        Converts the :py:class:`luigi.task.Task` (sub) class to its family name.
        """
        return json.dumps([cls.task_family for cls in cls_list])


