import luigi
from luigi import task_register

from datasets import BostonDataset


class TaskA(luigi.Task):
    p1 = luigi.parameter.IntParameter()

    def output(self):
        return luigi.LocalTarget('C:\\Users\\valeriy.ischenko\\Documents\\temp\\taska_%d.txt' % (self.p1, ))

    def run(self):
        print 'taska: ', self.output().path
        with self.output().open('w') as f:
            f.write('%s' % (self.p1,))


# class TaskB(luigi.Task):
#     t1 = luigi.parameter.TaskParameter()
#     t2 = luigi.parameter.TaskParameter()
#
#     def requires(self):
#         print self.t1
#         print self.t2
#         return [self.t1, self.t2]
#
#     def output(self):
#         return luigi.LocalTarget(is_tmp=True)
#
#     def run(self):
#         with self.output().open('w') as f_out:
#             f_out.write('Done')
#
#
# class TaskC(luigi.Task):
#     t1 = luigi.parameter.TaskParameter()
#     t2 = luigi.parameter.TaskParameter()
#
#     def requires(self):
#         print self.t1
#         print self.t2
#         return [self.t1, self.t2]
#
#     def output(self):
#         return luigi.LocalTarget(is_tmp=True)
#
#     def run(self):
#         with self.output().open('w') as f_out:
#             f_out.write('Done')


class TaskD(luigi.Task):
    def requires(self):
        return {'a1': TaskA(1), 'a2': TaskA(2)}
        # return [TaskA(p1=1), TaskA(p1=2)]

    def output(self):
        return luigi.LocalTarget('C:\\Users\\valeriy.ischenko\\Documents\\temp\\taskd.txt')

    def run(self):
        print 'taskd: ', self.input()
        with self.output().open('w') as f_out:
            f_out.write('Done')


class Main(luigi.Task):
    def requires(self):
        # ta1 = TaskA(1)
        # print ta1.task_family
        # print task_register.Register.get_task_cls('TaskA')
        # print task_register.Register.get_task_cls('TaskA')(**{'p1':3})
        # ta2 = TaskA(2)
        #
        # print task_register.Register.get_task_cls('BostonDataset')
        #
        # tb1 = TaskB(t1=ta1, t2=ta2)
        # print tb1.task_family
        #
        # return tb1
        td = TaskD()
        return td


if __name__ == '__main__':
    luigi.run(local_scheduler=True, main_task_cls=Main)