import os
import copy

import pandas as pd
from sklearn.cross_validation import ShuffleSplit, StratifiedShuffleSplit, KFold, StratifiedKFold

import luigi
from luigi import task_register

from features import extract_column_types, DataFrameImputer, DataFrameEncoder, ColumnOHEEncoder, DataFrameWOEEncoder
from features import ColumnHashTrickEncoder, DataFrameDateEncoder


def setup_permissions(filename):
    os.chmod(filename, 0774)


class PipelineException(Exception):
    pass


def instantiate_task(task_template):
    task_name = task_template['task']
    task_params = task_template['parameters']
    task = task_register.Register.get_task_cls(task_name)
    return task(**task_params)


def extract_tasks_list(task_template):
    if isinstance(task_template['task'], (list, tuple)):
        task_templates_list = []
        for task_name, task_parameters in zip(task_template['task'], task_template['parameters']):
            task_templates_list.append({'task': task_name, 'parameters': task_parameters})
        return task_templates_list
    else:
        raise ValueError('Must be list of tasks')


def instantiate(task_template):
    # todo: check if both task_template['task'] and task_template['parameters'] are tuples
    # todo: check that in this case lengths are the same
    if isinstance(task_template['task'], (list, tuple)):
        task_templates_list = extract_tasks_list(task_template)
        return [instantiate_task(task) for task in task_templates_list]
    else:
        return instantiate_task(task_template)


def update_tag_with_parameters(chain, tag, parameters):
    if chain is not None:
        if 'task' not in chain:
            for key, value in chain.items():
                update_tag_with_parameters(value, tag, parameters)
        elif isinstance(chain['task'], (list, tuple)):
            # fixme: it won't work because of creating new dicts
            # todo: re-create structure and return it
            task_templates_list = extract_tasks_list(chain)
            for task in task_templates_list:
                update_tag_with_parameters(task, tag, parameters)
        else:
            if 'tag' in chain and chain['tag'] == tag:
                chain['parameters'].update(parameters)
            if 'input_data' in chain['parameters']:
                update_tag_with_parameters(chain['parameters']['input_data'], tag, parameters)


class Chain(object):
    def __init__(self, chain=None):
        self.chain = chain

    def add(self, task, tag=None, **task_parameters):
        if self.chain is None:
            self.chain = {'task': task.task_family, 'parameters': task_parameters}
        else:
            params = dict(task_parameters)
            params['input_data'] = self.chain
            self.chain = {'task': task.task_family, 'parameters': params}
        if tag is not None:
            self.chain['tag'] = tag

    def add_from_template(self, task_dict):
        task_dict = copy.deepcopy(task_dict)
        task_dict['parameters']['input_data'] = self.chain
        self.chain = task_dict

    def checkpoint(self):
        # todo: think if we really need deep copy here
        return Chain(chain=copy.deepcopy(self.chain))

    def instantiate(self):
        return instantiate(self.chain)

    @staticmethod
    def combine_chains(chains, task, **task_parameters):
        params = dict(task_parameters)
        if isinstance(chains, (tuple, list)):
            task_name_list = tuple([chain.chain['task'] for chain in chains])
            task_params_list = tuple([chain.chain['parameters'] for chain in chains])
            params['input_data'] = {'task': task_name_list, 'parameters': task_params_list}
        elif isinstance(chains, (dict, luigi.parameter.FrozenOrderedDict)):
            if 'task' in chains:
                raise KeyError('For several chains combination must not be any chain with "task" key')
            params['input_data'] = copy.deepcopy(chains)
        return Chain(chain={'task': task.task_family, 'parameters': params})

    @staticmethod
    def create_task_template(task, **task_parameters):
        chain = Chain()
        chain.add(task, **task_parameters)
        return chain.chain


class PipelineTask(luigi.Task):
    input_data = luigi.parameter.DictParameter()

    def requires(self):
        # todo: fix this issue with logging (use conf file?)
        import logging
        logging.getLogger('luigi-interface').setLevel(logging.INFO)
        if self.input_data is not None:
            if 'task' in self.input_data:
                return instantiate(self.input_data)
            else:
                requirements = {}
                for key, value in self.input_data.items():
                    requirements[key] = instantiate(value)
                return requirements
        else:
            return []


class Path(object):
    def __init__(self, path_config, dataset_config=None):
        self.path_config = path_config
        self.dataset_config = dataset_config

    def makedirs(self, name, mode=0774):
        """Create dir and ensure to setup permissions. Function borrowed from python standard library"""
        head, tail = os.path.split(name)
        if not tail:
            head, tail = os.path.split(head)
        if head and tail and not os.path.exists(head):
            self.makedirs(head, mode)
            if tail == os.curdir:  # xxx/newdir/. exists if xxx/newdir exists
                return
        try:
            os.mkdir(name, mode)
        except OSError, e:
            # be happy if someone already created the path
            if e.errno != os.errno.EEXIST:
                raise
        os.chmod(name, mode)

    def get_raw_data_path(self):
        return os.path.join(self.path_config['dataset_path'], 'raw', self.path_config['dataset_name'])

    def get_data_path(self):
        folder = os.path.join(self.path_config['dataset_path'], 'processed', self.path_config['dataset_name'])
        self.makedirs(folder)
        return folder

    def get_experiment_path(self):
        folder = os.path.join(
            self.path_config['experiments_path'],
            self.path_config['experiment_name']
        )
        self.makedirs(folder)
        return folder


class Split(PipelineTask):
    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    ratio = luigi.parameter.FloatParameter(default=0.7, description='Train part of the dataset')
    stratified = luigi.parameter.BoolParameter(default=True)
    seed = luigi.parameter.IntParameter(default=42)
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def _create_param_string(self):
        return '%s_%d_%.1f_%s' % (self.dataset_config['target'], self.seed, self.ratio, self.stratified)

    def _create_out_filename(self, part):
        path = Path(self.path_config, self.dataset_config).get_data_path()
        folder = self._create_param_string()
        return os.path.join(
            path,
            folder,
            '%s__%s.csv' % (part, folder)
        )

    def output(self):
        # todo: check if we can change it to namedtuple
        return {
            'train': luigi.LocalTarget(self._create_out_filename('train')),
            'test': luigi.LocalTarget(self._create_out_filename('test'))
        }

    def run(self):
        with self.input().open() as f:
            df = pd.read_csv(f)
        target = df[self.dataset_config['target']]
        target_unique_values = target.unique()
        if len(target_unique_values) == 2 and set(target_unique_values) != {0, 1}:
            raise PipelineException('Please use 0/1 for binary targets')
        if self.stratified and len(target.unique()) != 2:
            raise PipelineException('Stratified splitting is supported only for binary classification')
        if self.stratified:
            sss = StratifiedShuffleSplit(target, n_iter=1, train_size=self.ratio, test_size=None,
                                         random_state=self.seed)
            train_idx, validation_idx = sss.__iter__().next()
        else:
            ss = ShuffleSplit(target.shape[0], n_iter=1, train_size=self.ratio, test_size=None,
                              random_state=self.seed)
            train_idx, validation_idx = ss.__iter__().next()
        train_part = df.iloc[train_idx]
        validation_part = df.iloc[validation_idx]
        with self.output()['train'].open(mode='w') as of_train:
            train_part.to_csv(of_train, index=False)
        setup_permissions(self.output()['train'].path)
        with self.output()['test'].open(mode='w') as of_test:
            validation_part.to_csv(of_test, index=False)
        setup_permissions(self.output()['test'].path)


class ExtractPartOfOutput(PipelineTask):
    part_name = luigi.parameter.Parameter(description='Which part to extract, usually train or test')

    def output(self):
        return self.input()[self.part_name]


class CVSplit(PipelineTask):
    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    folds = luigi.parameter.IntParameter(default=5)
    stratified = luigi.parameter.BoolParameter(default=True)
    seed = luigi.parameter.IntParameter(default=42)
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def _create_out_filename(self, part, fold):
        # todo: think about using path class instead of path of previous task
        head, tail = os.path.split(self.input().path)
        filename = '%s__fold_%d(%d)__%s_%d_%s.csv' % \
                   (part, fold, self.folds, self.dataset_config['target'], self.seed, self.stratified)
        return os.path.join(head, filename)

    def output(self):
        output_folds = []
        for i in xrange(self.folds):
            output_folds.append({
                'train': luigi.LocalTarget(self._create_out_filename('train', i+1)),
                'test': luigi.LocalTarget(self._create_out_filename('test', i+1))
            })
        return output_folds

    def run(self):
        with self.input().open() as f:
            df = pd.read_csv(f)
        target = df[self.dataset_config['target']]
        if self.stratified and len(target.unique()) != 2:
            raise PipelineException('Stratified splitting is supported only for binary classification')
        if self.stratified:
            ss = StratifiedKFold(target, n_folds=self.folds, shuffle=True, random_state=self.seed)
        else:
            ss = KFold(target.shape[0], n_folds=self.folds, shuffle=True, random_state=self.seed)
        for (train_idx, validation_idx), outputs in zip(ss, self.output()):
            train_part = df.iloc[train_idx]
            validation_part = df.iloc[validation_idx]
            with outputs['train'].open(mode='w') as of_train:
                train_part.to_csv(of_train, index=False)
            setup_permissions(outputs['train'].path)
            with outputs['test'].open(mode='w') as of_test:
                validation_part.to_csv(of_test, index=False)
            setup_permissions(outputs['test'].path)


class FoldSeparator(PipelineTask):
    fold_number = luigi.parameter.IntParameter()

    def output(self):
        return self.input()[self.fold_number]


class UpdateTagWrapper(PipelineTask):
    tag = luigi.parameter.Parameter(description='Tag name to look for in chain')
    parameters = luigi.parameter.DictParameter(description='Parameters to update')

    def requires(self):
        self.input_data = copy.deepcopy(self.input_data)
        update_tag_with_parameters(self.input_data, self.tag, self.parameters)
        return super(UpdateTagWrapper, self).requires()

    def output(self):
        return self.input()


class FeaturesGeneration(PipelineTask):
    # todo: add hash trick encoder for categorical columns with many categories
    dataset_config = luigi.parameter.DictParameter()

    def _create_out_filename(self, part):
        # FIXME: pass all parameters here?
        path, ext = os.path.splitext(self.input()[part].path)
        return path + '_features' + ext

    def output(self):
        return {
            'train': luigi.LocalTarget(self._create_out_filename('train')),
            'test': luigi.LocalTarget(self._create_out_filename('test'))
        }

    def _remove_columns(self, dataframe, column_list):
        data_columns = dataframe.columns.difference(column_list)
        return dataframe[data_columns]

    def _apply_transformer(self, transformer, train_data, test_data, train_result, test_result):
        train_result.append(transformer.transform(train_data))
        test_result.append(transformer.transform(test_data))

    def run(self):
        with self.input()['train'].open() as f:
            train_data = pd.read_csv(f)
        with self.input()['test'].open() as f:
            test_data = pd.read_csv(f)

        train_result = []
        test_result = []

        train_target = train_data.pop(self.dataset_config['target'])
        test_target = test_data.pop(self.dataset_config['target'])
        if len(self.dataset_config['ignore_columns']) > 0:
            train_data = self._remove_columns(train_data, self.dataset_config['ignore_columns'])
            test_data = self._remove_columns(test_data, self.dataset_config['ignore_columns'])

        if len(self.dataset_config['date_columns']) > 0:
            date_columns = [i['name'] for i in self.dataset_config['date_columns']]
            date_formats = [i['format'] for i in self.dataset_config['date_columns']]
            train_data_dates = train_data[date_columns]
            test_data_dates = test_data[date_columns]

            date_encoder = DataFrameDateEncoder(pairwise_difference=True, date_format=date_formats)
            date_encoder.fit(train_data_dates)

            train_result.append(date_encoder.transform(train_data_dates))
            test_result.append(date_encoder.transform(test_data_dates))

            train_data = self._remove_columns(train_data, date_columns)
            test_data = self._remove_columns(test_data, date_columns)

        column_types = extract_column_types(train_data)

        num_imputer = DataFrameImputer(add_nan_flags=True)
        num_imputer.fit(train_data[column_types.num_columns])
        train_result.append(num_imputer.transform(train_data[column_types.num_columns]))
        test_result.append(num_imputer.transform(test_data[column_types.num_columns]))

        ohe_encoder = DataFrameEncoder(ColumnOHEEncoder())
        ohe_encoder.fit(train_data[column_types.cat_columns])
        train_result.append(ohe_encoder.transform(train_data[column_types.cat_columns]))
        test_result.append(ohe_encoder.transform(test_data[column_types.cat_columns]))

        # todo: fix inf problem with WOE encoder, test on boston income dataset
        # should be fixed
        woe_encoder = DataFrameWOEEncoder()
        all_cat_columns = column_types.cat_columns + column_types.cat_high_cardinality_columns
        woe_encoder.fit(train_data[all_cat_columns], train_target)
        train_result.append(woe_encoder.transform(train_data[all_cat_columns]))
        test_result.append(woe_encoder.transform(test_data[all_cat_columns]))

        hashtrick_encoder = DataFrameEncoder(ColumnHashTrickEncoder())
        hashtrick_encoder.fit(train_data[column_types.cat_high_cardinality_columns])
        train_result.append(hashtrick_encoder.transform(train_data[column_types.cat_high_cardinality_columns]))
        test_result.append(hashtrick_encoder.transform(test_data[column_types.cat_high_cardinality_columns]))

        train_features = pd.concat(train_result, axis=1)
        train_features[self.dataset_config['target']] = train_target
        test_features = pd.concat(test_result, axis=1)
        test_features[self.dataset_config['target']] = test_target

        with self.output()['train'].open(mode='w') as of_train:
            train_features.to_csv(of_train, index=False)
        setup_permissions(self.output()['train'].path)
        with self.output()['test'].open(mode='w') as of_test:
            test_features.to_csv(of_test, index=False)
        setup_permissions(self.output()['test'].path)
