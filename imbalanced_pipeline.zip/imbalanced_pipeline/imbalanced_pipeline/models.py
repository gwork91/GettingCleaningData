import base64
import copy
import json
import os
import cPickle
import time
from collections import defaultdict

import itertools
import numpy as np
import pandas as pd

from sklearn import ensemble
from sklearn.metrics import roc_auc_score

import luigi

from tasks import setup_permissions, PipelineTask, instantiate, PipelineException, Chain, extract_tasks_list, Path


def hash_nested(obj):
    if isinstance(obj, (tuple, list)):
        return hash(tuple([hash_nested(e) for e in obj]))
    elif isinstance(obj, set):
        return hash(tuple([hash_nested(sorted(e)) for e in obj]))
    elif not isinstance(obj, (dict, luigi.parameter.FrozenOrderedDict)):
        return hash(obj)
    else:
        copied = dict(copy.deepcopy(obj))
        for key, value in copied.items():
            copied[key] = hash_nested(value)
        return hash(tuple(frozenset(sorted(copied.items()))))


class Model(PipelineTask):
    name = None

    save_model = luigi.parameter.BoolParameter(default=False, description='Saving model to disk')
    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def _get_parameters_hash(self):
        params = self.get_parameters()
        return base64.b32encode(bytes(hash(frozenset(params.items()))))

    def _create_experiment_path(self):
        return Path(self.path_config, self.dataset_config).get_experiment_path()

    def _create_out_filename(self, part):
        extension = {'model': 'pkl', 'result': 'json'}
        params_hash = self._get_parameters_hash()
        head, tail = os.path.split(self.input()['train'].path)
        info = tail.split('__', 1)[1]
        info, ext = os.path.splitext(info)

        return os.path.join(
            self._create_experiment_path(),
            '%s_%s__%s.%s' % (part, params_hash, info, extension[part])
        )

    def output(self):
        outputs = {'result': luigi.LocalTarget(self._create_out_filename('result'))}
        if self.save_model:
            outputs['model'] = luigi.LocalTarget(self._create_out_filename('model')),
        return outputs

    def run(self):
        with self.input()['train'].open() as f:
            train_data = pd.read_csv(f)
        with self.input()['test'].open() as f:
            test_data = pd.read_csv(f)

        train_target = train_data.pop(self.dataset_config['target'])
        test_target = test_data.pop(self.dataset_config['target'])

        start = time.time()
        model = self.fit(train_data, train_target)
        total_train_time = time.time() - start

        if self.save_model:
            with self.output()['model'].open(mode='wb') as f:
                cPickle.dump(model, f, cPickle.HIGHEST_PROTOCOL)
            setup_permissions(self.output()['model'].path)

        start = time.time()
        predictions = self.predict(test_data)
        total_prediction_time = time.time() - start
        scores = self.score(test_target, predictions)

        results = dict(
            train=self.input()['train'].path,
            test=self.input()['test'].path,
            train_shape=train_data.shape,
            model_name=self.name,
            model_parameters=self.get_parameters(),
            model_parameters_hash=self._get_parameters_hash(),
            model_train_time=total_train_time,
            model_prediction_time=total_prediction_time,
            scores=scores
        )

        with self.output()['result'].open(mode='w') as f:
            json.dump(results, f, indent=4, sort_keys=True)
        setup_permissions(self.output()['result'].path)

    def fit(self, train_data, train_target):
        raise NotImplementedError()

    def predict(self, test_data):
        raise NotImplementedError()

    def score(self, true_target, predicted_target):
        raise NotImplementedError()

    def get_parameters(self):
        raise NotImplementedError()


class GridSearch(PipelineTask):
    # todo: add wrapper name to docstring
    """
    Underlying model for GridSearch must support passing all parameters as parameters dict.
    Use wrapper or TrainFold class to do it.
    """
    # todo: think about not having model template here, but only parameters grid.
    # todo: in this case TrainFolds should be able to get parameters and put them as parameters for underline model
    parameters_grid = luigi.parameter.DictParameter(description='Parameters grid to perform grid search')
    metric = luigi.parameter.Parameter(description='Name of the metric, must be in scores section of model output')
    # todo: find better name for this parameter
    descending_order = luigi.parameter.BoolParameter(description='The sort order for metric. True, if higher is better')
    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def _get_parameters_hash(self):
        # todo: remove model_template here
        # model = dict(copy.deepcopy(self.model_template))
        # model['parameters_grid'] = self.parameters_grid
        # fixme: add "default" parameters of the underlying models to the hash
        # todo: it's temporary fix, that use whole pipeline description + parameters_grid
        pipeline = dict(copy.deepcopy(self.input_data))
        pipeline['parameters_grid'] = self.parameters_grid
        # return base64.b32encode(bytes(hash_nested(self.parameters_grid)))
        return base64.b32encode(bytes(hash_nested(pipeline)))

    def requires(self):
        requirements = []
        param_names = self.parameters_grid.keys()
        for param_set in itertools.product(*self.parameters_grid.values()):
            current_params = dict(zip(param_names, param_set))
            chain_template = copy.deepcopy(self.input_data)
            chain_template['parameters']['parameters'] = current_params
            requirements.append(Chain(chain_template).instantiate())
        return requirements

    def _create_output_filename(self, task):
        head, tail = os.path.split(self.input()[0]['result'].path)
        # head, tail = os.path.split(self.input()[0].path)
        filename_parts = tail.split('__', 2)
        return os.path.join(head, 'gridsearch_%s__%s__%s' % (self._get_parameters_hash(), task, filename_parts[2]))

    def output(self):
        return {
            'result': luigi.LocalTarget(self._create_output_filename('result')),
            'history': luigi.LocalTarget(self._create_output_filename('history')),
            'best_parameters': luigi.LocalTarget(self._create_output_filename('best_parameters')),
            'grid_parameters': luigi.LocalTarget(self._create_output_filename('grid_parameters')),
        }

    def run(self):
        results = []
        for input_file in self.input():
            # with input_file.open() as f:
            with input_file['result'].open() as f:
                result = json.load(f)
                results.append(result)

        results = sorted(results, key=lambda x: (x['scores'][self.metric]['mean'], x['scores'][self.metric]['std'],
                                                 x['model_train_time']['mean']),
                         reverse=self.descending_order)

        with self.output()['result'].open(mode='w') as f:
            json.dump(results[0], f, indent=4, sort_keys=True)
        setup_permissions(self.output()['result'].path)
        with self.output()['history'].open(mode='w') as f:
            json.dump(results, f, indent=4, sort_keys=True)
        setup_permissions(self.output()['history'].path)
        with self.output()['best_parameters'].open(mode='w') as f:
            json.dump(results[0]['model_parameters'], f, indent=4, sort_keys=True)
        setup_permissions(self.output()['best_parameters'].path)
        with self.output()['grid_parameters'].open(mode='w') as f:
            json.dump(dict(self.parameters_grid), f, indent=4, sort_keys=True)
        setup_permissions(self.output()['grid_parameters'].path)


# class GridSearch(PipelineTask):
#     # todo: think about not having model template here, but only parameters grid.
#     # todo: in this case TrainFolds should be able to get parameters and put them as parameters for underline model
#     model_template = luigi.parameter.DictParameter(description='Template for model with parameters to perform training')
#     parameters_grid = luigi.parameter.DictParameter(description='Parameters grid to perform grid search')
#     metric = luigi.parameter.Parameter(description='Name of the metric, must be in scores section of model output')
#     # todo: find better name for this parameter
#     descending_order = luigi.parameter.BoolParameter(description='The sort order for metric. True, if higher is better')
#     dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
#     path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')
#
#     def _get_parameters_hash(self):
#         model = dict(copy.deepcopy(self.model_template))
#         model['parameters_grid'] = self.parameters_grid
#         return base64.b32encode(bytes(hash_nested(model)))
#
#     def requires(self):
#         requirements = []
#         param_names = self.parameters_grid.keys()
#         for param_set in itertools.product(*self.parameters_grid.values()):
#             current_params = dict(zip(param_names, param_set))
#             model = copy.deepcopy(self.model_template)
#             model['parameters'].update(current_params)
#             chain_template = copy.deepcopy(self.input_data)
#             chain_template['parameters']['model'] = model
#             requirements.append(Chain(chain_template).instantiate())
#         return requirements
#
#     def output(self):
#         # head, tail = os.path.split(self.input()['result'][0].path)
#         head, tail = os.path.split(self.input()[0].path)
#         filename_parts = tail.split('__', 2)
#         result_filename = 'gridsearch_%s__result__%s' % (self._get_parameters_hash(), filename_parts[2])
#         bp_filename = 'gridsearch_%s__best_parameters__%s' % (self._get_parameters_hash(), filename_parts[2])
#         return {
#             'result': luigi.LocalTarget(os.path.join(head, result_filename)),
#             'best_parameters': luigi.LocalTarget(os.path.join(head, bp_filename)),
#         }
#
#     def run(self):
#         results = []
#         for input_file in self.input():
#             # with input_file['result'].open() as f:
#             with input_file.open() as f:
#                 result = json.load(f)
#                 results.append(result)
#
#         results = sorted(results, key=lambda x: (x['scores'][self.metric]['mean'], x['scores'][self.metric]['std'],
#                                                  x['model_train_time']['mean']),
#                          reverse=self.descending_order)
#
#         # todo: add parameters grid to output
#         with self.output()['result'].open(mode='w') as f:
#             json.dump(results, f, indent=4, sort_keys=True)
#         setup_permissions(self.output()['result'].path)
#         with self.output()['best_parameters'].open(mode='w') as f:
#             json.dump(results[0]['model_parameters'], f, indent=4, sort_keys=True)
#         setup_permissions(self.output()['best_parameters'].path)
#
#
class TrainFolds(PipelineTask):
    parameters = luigi.parameter.DictParameter(description='Parameters to train underlying model')
    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def requires(self):
        if self.input_data is not None and isinstance(self.input_data['task'], (list, tuple)):
            task_templates_list = extract_tasks_list(self.input_data)
            requirements = []
            for chain_description in task_templates_list:
                chain_description = copy.deepcopy(chain_description)
                chain_description['parameters'].update(self.parameters)
                chain = Chain(chain=chain_description)
                requirements.append(chain.instantiate())
            return requirements
        else:
            raise PipelineException('TrainFolds should have list of tasks as input')

    def output(self):
        head, tail = os.path.split(self.input()[0]['result'].path)
        filename_parts = tail.split('__', 2)
        new_filename = '%s__folds_aggregated__%s' % (filename_parts[0], filename_parts[2])
        return {'result': luigi.LocalTarget(os.path.join(head, new_filename))}

    def append(self, combined, origin, keys=None):
        if keys is None:
            keys = origin.keys()
        for field_name in keys:
            combined[field_name].append(origin[field_name])
        return combined

    def aggregate(self, combined, keys=None):
        if keys is None:
            keys = combined.keys()
        for field_name in keys:
            values = combined[field_name]
            mean = np.mean(values)
            std = np.std(values)
            combined[field_name] = dict(values=values, mean=mean, std=std)
        return combined

    def copy_and_check(self, combined, origin, exclusions=None):
        """
        Copy all keys from origin dict to combined if new. Check that they are the same, if already exists.
        Ignoring exclusions key
        :param combined:
        :param origin:
        :param exclusions:
        :return:
        """
        if exclusions is None:
            exclusions = set()
        else:
            exclusions = set(exclusions)
        for key, value in origin.items():
            if key not in exclusions:
                if key not in combined:
                    combined[key] = value
                elif combined[key] != origin[key]:
                    raise ValueError('Model returned different values for unexpected fields %s: %s != %s',
                                     (str(key), str(combined[key]), str(origin[key])))

    def run(self):
        aggregating_keys = ['model_train_time', 'model_prediction_time']
        combining_keys = ['test', 'train', 'train_shape']
        scores_key = ['scores']

        combined_results = defaultdict(list)
        combined_results['scores'] = defaultdict(list)
        for input_file in self.input():
            with input_file['result'].open() as f:
                result = json.load(f)
                self.append(combined_results, result, keys=aggregating_keys + combining_keys)
                self.append(combined_results['scores'], result['scores'])
                self.copy_and_check(combined_results, result, exclusions=aggregating_keys + combining_keys + scores_key)
        self.aggregate(combined_results, keys=aggregating_keys)
        self.aggregate(combined_results['scores'])

        with self.output()['result'].open(mode='w') as f:
            json.dump(combined_results, f, indent=4, sort_keys=True)
        setup_permissions(self.output()['result'].path)


# class TrainFolds(PipelineTask):
#     model = luigi.parameter.DictParameter(description='Template for model with parameters to perform training')
#     dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
#     path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')
#
#     def requires(self):
#         if self.input_data is not None and isinstance(self.input_data['task'], (list, tuple)):
#             task_templates_list = extract_tasks_list(self.input_data)
#             requirements = []
#             for chain_description in task_templates_list:
#                 chain = Chain(chain=chain_description)
#                 chain.add_from_template(self.model)
#                 requirements.append(chain.instantiate())
#             return requirements
#         else:
#             raise PipelineException('TrainFolds should have list of tasks as input')
#
#     def output(self):
#         head, tail = os.path.split(self.input()[0]['result'].path)
#         filename_parts = tail.split('__', 2)
#         new_filename = '%s__folds_aggregated__%s' % (filename_parts[0], filename_parts[2])
#         # todo: think about returning it in dict with 'result' key for unification
#         return luigi.LocalTarget(os.path.join(head, new_filename))
#
#     def append(self, combined, origin, keys=None):
#         if keys is None:
#             keys = origin.keys()
#         for field_name in keys:
#             combined[field_name].append(origin[field_name])
#         return combined
#
#     def aggregate(self, combined, keys=None):
#         if keys is None:
#             keys = combined.keys()
#         for field_name in keys:
#             values = combined[field_name]
#             mean = np.mean(values)
#             std = np.std(values)
#             combined[field_name] = dict(values=values, mean=mean, std=std)
#         return combined
#
#     def copy_and_check(self, combined, origin, exclusions=None):
#         """
#         Copy all keys from origin dict to combined if new. Check that they are the same, if already exists.
#         Ignoring exclusions key
#         :param combined:
#         :param origin:
#         :param exclusions:
#         :return:
#         """
#         if exclusions is None:
#             exclusions = set()
#         else:
#             exclusions = set(exclusions)
#         for key, value in origin.items():
#             if key not in exclusions:
#                 if key not in combined:
#                     combined[key] = value
#                 elif combined[key] != origin[key]:
#                     raise ValueError('Model returned different values for unexpected fields %s: %s != %s',
#                                      (str(key), str(combined[key]), str(origin[key])))
#
#     def run(self):
#         aggregating_keys = ['model_train_time', 'model_prediction_time']
#         combining_keys = ['test', 'train']
#         scores_key = ['scores']
#
#         combined_results = defaultdict(list)
#         combined_results['scores'] = defaultdict(list)
#         for input_file in self.input():
#             with input_file['result'].open() as f:
#                 result = json.load(f)
#                 self.append(combined_results, result, keys=aggregating_keys + combining_keys)
#                 self.append(combined_results['scores'], result['scores'])
#                 self.copy_and_check(combined_results, result, exclusions=aggregating_keys + combining_keys + scores_key)
#         self.aggregate(combined_results, keys=aggregating_keys)
#         self.aggregate(combined_results['scores'])
#
#         with self.output().open(mode='w') as f:
#             json.dump(combined_results, f, indent=4, sort_keys=True)
#         setup_permissions(self.output().path)


class ApplyParameters(PipelineTask):
    model_template = luigi.parameter.DictParameter(description='Template for model with parameters to perform training')

    def requires(self):
        if 'parameters' not in self.input_data or 'data' not in self.input_data:
            raise PipelineException('ApplyParameters task needs parameters and data inputs')
        return instantiate(self.input_data['parameters'])

    def output(self):
        head, tail = os.path.split(self.input().path)
        # filename_parts = tail.split('__', 2)
        new_filename = 'holdout__%s' % (tail,)
        # todo: think about returning it in dict with 'result' key for unification
        return luigi.LocalTarget(os.path.join(head, new_filename))

    def run(self):
        with self.input().open() as f:
            model_parameters = json.load(f)
        model_template = copy.deepcopy(self.model_template)
        model_template['parameters'].update(model_parameters)
        model_template['parameters']['input_data'] = self.input_data['data']
        model_result_target = yield instantiate(model_template)
        with model_result_target['result'].open() as f:
            model_result = json.load(f)
        with self.output().open(mode='w') as f:
            json.dump(model_result, f, indent=4, sort_keys=True)
        setup_permissions(self.output().path)


class RandomForestClassifier(Model):
    name = 'RandomForestClassifier'

    n_estimators = luigi.parameter.IntParameter(default=10)
    criterion = luigi.parameter.Parameter(default='gini')
    max_depth = luigi.parameter.Parameter(default=None)
    min_samples_split = luigi.parameter.IntParameter(default=2)
    min_samples_leaf = luigi.parameter.IntParameter(default=1)
    min_weight_fraction_leaf = luigi.parameter.FloatParameter(default=0.)
    max_features = luigi.parameter.Parameter(default='auto')
    max_leaf_nodes = luigi.parameter.Parameter(default=None)
    bootstrap = luigi.parameter.BoolParameter(default=True)
    oob_score = luigi.parameter.BoolParameter(default=False)
    # todo: add support for dictionary with class weights, not only predefined strings
    class_weight = luigi.parameter.Parameter(default=None)
    n_jobs = luigi.parameter.IntParameter(default=4),
    random_state = luigi.parameter.IntParameter(default=0)

    def get_max_depth(self):
        if self.max_depth is None or self.max_depth == 'None':
            return None
        else:
            return int(self.max_depth)

    def get_max_leaf_nodes(self):
        if self.max_leaf_nodes is None or self.max_leaf_nodes == 'None':
            return None
        else:
            return int(self.max_leaf_nodes)

    def get_max_features(self):
        if self.max_features is None or self.max_features == 'None':
            return None
        elif self.max_features in ['auto', 'sqrt', 'log2']:
            return self.max_features
        else:
            try:
                mf = int(self.max_features)
            except KeyError:
                try:
                    mf = float(self.max_features)
                except KeyError:
                    # todo: add warning
                    mf = 'auto'
            return mf

    def get_class_weight(self):
        if self.class_weight is None or self.class_weight == 'None':
            return None
        elif self.class_weight in ['balanced', 'balanced_subsample']:
            return self.class_weight
        else:
            # todo: add warning
            return None

    def fit(self, train_data, train_target):
        self.model = ensemble.RandomForestClassifier(**self.get_parameters())
        self.model.fit(train_data, train_target)
        return self.model

    def predict(self, test_data):
        return self.model.predict_proba(test_data)[:, 1]

    def score(self, true_target, predicted_target):
        return {'auc': roc_auc_score(true_target, predicted_target)}

    def get_parameters(self):
        return dict(
            n_estimators=self.n_estimators,
            criterion=self.criterion,
            max_depth=self.get_max_depth(),
            min_samples_split=self.min_samples_split,
            min_samples_leaf=self.min_samples_leaf,
            min_weight_fraction_leaf=self.min_weight_fraction_leaf,
            max_features=self.get_max_features(),
            max_leaf_nodes=self.get_max_leaf_nodes(),
            bootstrap=self.bootstrap,
            class_weight=self.get_class_weight(),
            random_state=self.random_state
        )
