import functools
import itertools
from collections import namedtuple

import numpy as np
import pandas as pd

from sklearn.base import TransformerMixin
from sklearn.base import clone
from sklearn.feature_extraction import FeatureHasher
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import LabelEncoder, OneHotEncoder


ColumnTypes = namedtuple('ColumnTypes', ['num_columns', 'cat_columns', 'cat_high_cardinality_columns',
                                         'constant_columns', 'id_columns']
                         )


class DataFrameEncoder(TransformerMixin):
    def __init__(self, column_transformer):
        self.column_transformer = column_transformer
        self.columns = dict()

    def fit(self, X, y=None, **kwargs):
        if not isinstance(X, pd.DataFrame):
            raise ValueError('DataFrameEncoder is supporting only pandas.DataFrame as input')
        for column_name in X:
            self.columns[column_name] = clone(self.column_transformer, safe=False).fit(X[column_name], y, **kwargs)
        return self

    def transform(self, X, y=None, **kwargs):
        if not isinstance(X, pd.DataFrame):
            raise ValueError('DataFrameEncoder is supporting only pandas.DataFrame as input')
        encoded = pd.DataFrame()
        encoded_list = []
        for column_name in X:
            if column_name not in self.columns:
                raise KeyError('Unknown column ' + column_name)
            result = self.columns[column_name].transform(X[column_name], y, **kwargs)
            if isinstance(result, pd.DataFrame):
                encoded_list.append(result)
            else:
                encoded[column_name] = result
        if len(encoded_list) > 0:
            encoded = pd.concat([encoded] + encoded_list, axis=1)
        return encoded


class ColumnLabelEncoder(TransformerMixin):
    # fixme: to  not use string as rare and na values
    def __init__(self, threshold=10, fill_na_value='nan', fill_rare_value='rare'):
        self.threshold = threshold
        self.fill_na_value = fill_na_value
        self.fill_rare_value = fill_rare_value

    def fit(self, column, y=None):
        column = column.fillna(self.fill_na_value)
        counts = column.value_counts()
        self.rare_values = counts[counts < self.threshold].index
        self.label_encoder = LabelEncoder().fit(list(counts[counts >= self.threshold].index) + [self.fill_rare_value])
        return self

    def transform(self, column, y=None):
        column = column.fillna(self.fill_na_value)
        column[column.isin(self.rare_values)] = self.fill_rare_value
        # replace new values with rare_value
        # fixme: fixed replacement with string for now, revert back when remove using string
        # column[~column.isin(self.label_encoder.classes_)] = self.fill_rare_value
        column[~column.astype(self.label_encoder.classes_.dtype).isin(self.label_encoder.classes_)] = self.fill_rare_value
        # return pd.Series(self.label_encoder.transform(column), name=column.name)
        # fixme also
        return pd.Series(self.label_encoder.transform(column.astype(self.label_encoder.classes_.dtype)), name=column.name)




class ColumnOHEEncoder(TransformerMixin):
    def __init__(self, threshold=10, fill_na_value='nan', fill_rare_value='rare', separator='_$_'):
        self.column_label_encoder = ColumnLabelEncoder(threshold, fill_na_value, fill_rare_value)
        self.separator = unicode(separator)

    def fit(self, column, y=None):
        le_column = self.column_label_encoder.fit_transform(column)
        self.ohe_encoder = OneHotEncoder(n_values=len(self.column_label_encoder.label_encoder.classes_),
                                         sparse=False, handle_unknown='ignore').fit(le_column.reshape(-1, 1))
        return self

    def transform(self, column, y=None):
        le_column = self.column_label_encoder.transform(column)
        return pd.DataFrame(data=self.ohe_encoder.transform(le_column.reshape(-1, 1)),
                            columns=[unicode(column.name) + self.separator + unicode(i)
                                     for i in self.column_label_encoder.label_encoder.classes_])


class ColumnHashTrickEncoder(TransformerMixin):
    def __init__(self, n_features=None, fill_na_value='nan', separator='_$hash$_'):
        self.n_features = n_features
        self.fill_na_value = fill_na_value
        self.separator = unicode(separator)

    def fit(self, column, y=None):
        if self.n_features is None:
            unique_values = len(column.unique())
            # todo: is it better to use natural logarithm here?
            self.n_features = int(round(min(32, max(3, np.log2(unique_values)))))
        return self

    def transform(self, column, y=None):
        column = column.fillna(self.fill_na_value)
        inp = ({unicode(i): 1} for i in column)
        return pd.DataFrame(FeatureHasher(n_features=self.n_features, non_negative=True).transform(inp).toarray(),
                            columns=[unicode(column.name) + self.separator + unicode(i + 1)
                                     for i in xrange(self.n_features)])


class ColumnDateEncoder(TransformerMixin):
    def __init__(self, extract_day_of_month=True, extract_day_of_week=True, extract_month=True, extract_year=False, separator='_$date$_'):
        self.extract_day_of_month = extract_day_of_month
        self.extract_day_of_week = extract_day_of_week
        self.extract_month = extract_month
        self.extract_year = extract_year
        self.separator = unicode(separator)

    def fit(self, column, y=None):
        return self

    def transform(self, column, y=None):
        result = pd.DataFrame()
        # date_column = pd.DatetimeIndex(column)
        date_column = column.dt
        if self.extract_day_of_month:
            result[unicode(column.name) + self.separator + unicode('day_of_month')] = date_column.day
        if self.extract_day_of_week:
            result[unicode(column.name) + self.separator + unicode('day_of_week')] = date_column.dayofweek
        if self.extract_month:
            result[unicode(column.name) + self.separator + unicode('month')] = date_column.month
        if self.extract_year:
            result[unicode(column.name) + self.separator + unicode('year')] = date_column.year
        return result


class DataFrameDateEncoder(TransformerMixin):
    def __init__(self, pairwise_difference=None, date_format=None, difference_granulation='D',
                 # can be same as timedelta64[]: D, M, Y, etc
                 extract_day_of_month=True, extract_day_of_week=True, extract_month=True, extract_year=False,
                 separator='_$date$_'):
        self.date_column_encoder = DataFrameEncoder(
            ColumnDateEncoder(extract_day_of_month=extract_day_of_month,
                              extract_day_of_week=extract_day_of_week,
                              extract_month=extract_month,
                              extract_year=extract_year,
                              separator=separator)
        )
        self.pairwise_difference = pairwise_difference
        self.date_format = date_format
        self.difference_granulation = difference_granulation

    def fit(self, X, y=None):
        self.date_column_encoder.fit(X, y)
        if self.pairwise_difference is None:
            # heuristic: if there are too many date columns - don't do it
            if X.shape[1] > 5:
                self.pairwise_difference = False
            else:
                self.pairwise_difference = True
        # result = self.date_column_encoder.transform(X, y)
        # self.non_constant = result.apply(pd.Series.nunique) != 1
        return self

    def transform(self, X, y=None):
        if self.date_format is None:
            X = X.apply(functools.partial(pd.to_datetime, dayfirst=True))
        elif isinstance(self.date_format, (tuple, list)):
            if len(self.date_format) != X.shape[1]:
                raise ValueError('Length of date_format must be the same as number of columns in X')
            X_new = pd.DataFrame()
            for name, date_f in zip(X.columns, self.date_format):
                X_new[name] = X[name].apply(functools.partial(pd.to_datetime, format=date_f))
            X = X_new
        else:
            X = X.apply(functools.partial(pd.to_datetime, format=self.date_format))

        result = self.date_column_encoder.transform(X, y)
        # result = result.loc[:, self.non_constant[X.columns]]
        if self.pairwise_difference:
            for pair in itertools.combinations(X.columns, 2):
                diff_name = u'%s_%s' % (unicode(X[pair[0]].name), unicode(X[pair[1]].name))
                result[diff_name] = (X[pair[0]] - X[pair[1]]).astype('timedelta64[%s]' % self.difference_granulation)
        return result


class ColumnWOEEncoder(TransformerMixin):
    def __init__(self, threshold=10, fill_na_value='nan', fill_rare_value='rare'):
        self.column_label_encoder = ColumnLabelEncoder(threshold, fill_na_value, fill_rare_value)

    def fit(self, column, y):
        le_column = self.column_label_encoder.fit_transform(column)

        goods = y.groupby(le_column).sum()
        bads = y.groupby(le_column).count() - goods
        total_goods = sum(goods)
        total_bads = sum(bads)
        distr_goods = goods / total_goods
        distr_bads = bads / total_bads
        dg_0 = distr_goods == 0
        db_0 = distr_bads == 0
        distr_bads[db_0] = 1.0
        self.woe = pd.Series(np.log(distr_goods / distr_bads))
        # todo: should category be 0? maybe very big/small value depending on which outcome is missing?
        self.woe[dg_0] = 0.0
        self.woe[db_0] = 0.0

        for possible_value in range(len(self.column_label_encoder.label_encoder.classes_)):
            if possible_value not in self.woe:
                # todo: should unknown value be 0?
                self.woe.set_value(possible_value, 0.0)

        return self

    def transform(self, column, y=None):
        le_column = self.column_label_encoder.transform(column)
        woed = le_column.map(self.woe)
        woed.name = 'WOE_' + woed.name
        return woed


class DataFrameWOEEncoder(TransformerMixin):
    def __init__(self):
        self.woe_encoder = DataFrameEncoder(ColumnWOEEncoder())

    def fit(self, X, y):
        self.woe_encoder.fit(X, y)
        result = self.woe_encoder.transform(X, y)
        self.non_constant = result.apply(pd.Series.nunique) != 1
        return self

    def transform(self, X, y=None):
        result = self.woe_encoder.transform(X, y)
        result = result.loc[:, self.non_constant[X.columns]]
        result.rename(columns=lambda x: 'WOE_' + x, inplace=True)
        return result


class ColumnImputer(TransformerMixin):
    def __init__(self, **kwargs):
        self.imputer = Imputer(**kwargs)

    def fit(self, X, y=None):
        self.imputer.fit(np.array(X).reshape(-1, 1))
        return self

    def transform(self, X, y=None):
        imputed = self.imputer.transform(np.array(X).reshape(-1, 1))
        imputed = pd.Series(imputed.flatten(), name=X.name)

        return imputed


class DataFrameImputer(TransformerMixin):
    def __init__(self, add_nan_flags=False, **kwargs):
        self.add_nan_flags = add_nan_flags
        self.df_imputer = DataFrameEncoder(ColumnImputer(**kwargs))

    def fit(self, X, y=None):
        self.df_imputer.fit(X, y)
        if self.add_nan_flags:
            nan_flags = X.isnull()
            self.column_with_nan = nan_flags.apply(pd.Series.nunique) != 1
        return self

    def transform(self, X, y=None):
        result = self.df_imputer.transform(X, y)
        if self.add_nan_flags:
            nan_flags = (X.isnull()).astype(int)
            nan_flags = nan_flags.loc[:, self.column_with_nan[X.columns]]
            nan_flags.rename(columns=lambda x: 'isnan_' + x, inplace=True)
            result = pd.concat([result, nan_flags], axis=1)
        return result


def cat_unique_values(column, threshold=10):
    cat_counts = column.value_counts()
    count = sum(cat_counts >= threshold)
    if sum(~(cat_counts < threshold)) > 0:
        count += 1
    return count


def extract_column_types(data, cat_unique_limit=32, num_unique_min=3, verbose=1):
    cat_columns = []
    cat_high_cardinality_columns = []
    num_columns = []
    id_columns = []
    constant_columns = []
    for column_name, column_type in data.dtypes.iteritems():
        unique_count = len(data[column_name].unique())
        if column_type != np.dtype('float64') and unique_count == data[column_name].shape[0]:
            # all values in column are different - "id-type" column
            id_columns.append(column_name)
        elif unique_count == 1:
            constant_columns.append(column_name)
        elif column_type == np.dtype('O'):
            cuv = cat_unique_values(data[column_name])
            if cuv <= cat_unique_limit:
                cat_columns.append(column_name)
            else:
                cat_high_cardinality_columns.append(column_name)
        elif column_type == np.dtype('int64') or column_type == np.dtype('float64'):
            if unique_count <= num_unique_min:
                cat_columns.append(column_name)
            else:
                num_columns.append(column_name)
        elif verbose > 0:
            print 'Unknown type', column_name, column_type

    return ColumnTypes(num_columns, cat_columns, cat_high_cardinality_columns, constant_columns, id_columns)
