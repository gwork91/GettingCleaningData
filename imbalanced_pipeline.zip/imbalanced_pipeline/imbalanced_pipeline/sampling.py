import json
import os
import time
import base64

import pandas as pd

from imblearn import under_sampling, over_sampling
import luigi

from tasks import PipelineTask, setup_permissions, Path


class SamplingMethod(PipelineTask):
    name = None

    dataset_config = luigi.parameter.DictParameter(description='Dataset related information')
    path_config = luigi.parameter.DictParameter(significant=False, description='Dataset location related information')

    def _get_parameters_hash(self):
        params = self.get_parameters()
        return base64.b32encode(bytes(hash(frozenset(params.items()))))

    def _create_experiment_path(self):
        return Path(self.path_config, self.dataset_config).get_experiment_path()

    def _create_out_filename(self, part):
        extension = {'train': 'csv', 'sampling': 'json'}
        params_hash = self._get_parameters_hash()
        head, tail = os.path.split(self.input()['train'].path)
        info = tail.split('__', 1)[1]
        info, ext = os.path.splitext(info)

        fnn = '%s_%s__%s.%s' % (part, params_hash, info, extension[part])

        return os.path.join(
            self._create_experiment_path(),
            '%s_%s__%s.%s' % (part, params_hash, info, extension[part])
        )

    def output(self):
        outputs = {
            'result': luigi.LocalTarget(self._create_out_filename('sampling')),
            'train': luigi.LocalTarget(self._create_out_filename('train')),
            'test': self.input()['test']
        }
        # if self.save_model:
        #     outputs['model'] = luigi.LocalTarget(self._create_out_filename('model')),
        return outputs

    def run(self):
        with self.input()['train'].open() as f:
            train_data = pd.read_csv(f)

        train_target = train_data.pop(self.dataset_config['target'])

        start = time.time()
        sampled_data, sampled_target = self.sample(train_data, train_target)
        total_sample_time = time.time() - start
        sampled_data = pd.DataFrame(sampled_data, columns=train_data.columns)

        results = dict(
            data=self.input()['train'].path,
            sampler_name=self.name,
            sampler_parameters=self.get_parameters(),
            sampler_parameters_hash=self._get_parameters_hash(),
            sample_time=total_sample_time,
            original_shape=train_data.shape,
            sampled_shape=sampled_data.shape
        )

        with self.output()['result'].open(mode='w') as f:
            json.dump(results, f, indent=4, sort_keys=True)
        setup_permissions(self.output()['result'].path)

        sampled_data[self.dataset_config['target']] = sampled_target
        with self.output()['train'].open(mode='w') as of_train:
            sampled_data.to_csv(of_train, index=False)
        setup_permissions(self.output()['train'].path)

    def get_parameters(self):
        raise NotImplementedError()

    def sample(self, X, y):
        """
        Base class for all sampling methods
        :param X: numpy array with train data
        :param y: numpy array with target
        :return: (sampled_X, sampled_y)
        """
        raise NotImplementedError()


class RandomUnderSampling(SamplingMethod):
    name = 'Random_UnderSampling_imblearn'

    random_state = luigi.parameter.IntParameter(default=0)
    ratio = luigi.parameter.Parameter(default='auto')

    def get_ratio(self):
        if self.ratio is None or self.ratio == 'auto':
            return 'auto'
        else:
            try:
                return float(self.max_features)
            except KeyError:
                return 'auto'

    def sample(self, X, y):
        sampler = under_sampling.RandomUnderSampler(**self.get_parameters())
        return sampler.fit_sample(X, y)

    def get_parameters(self):
        return dict(ratio=self.get_ratio(), random_state=self.random_state)
