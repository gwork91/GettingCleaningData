import itertools
import json

import luigi

from datasets import BostonDataset
from models import RandomForestClassifier, TrainFolds, GridSearch, ApplyParameters
from sampling import RandomUnderSampling
from tasks import Chain, PipelineException, UpdateTagWrapper, setup_permissions
from tasks import Split, ExtractPartOfOutput, CVSplit, FoldSeparator, FeaturesGeneration


def create_task_chain(task_name, **task_parameters):
    return {'task': task_name.task_family, 'parameters': task_parameters}


def add_task_to_chain(chain, task_name, **task_parameters):
    params = dict(task_parameters)
    params['input_data'] = chain
    return {'task': task_name.task_family, 'parameters': params}


class SamplingPipeline(luigi.Task):
    datasets_path = None
    experiments_path = None

    test_train_split_ratio = 0.7
    test_train_split_stratified = True
    test_train_split_random_seed = 42

    cv_folds_count = 5
    cv_stratified = True
    cv_random_seed = 42

    metric = 'auc'
    metric_descending_order = True

    datasets = []
    sampling_task = None
    sampling_task_params_gird = None
    model_task = None
    model_task_params_grid = None

    dataset = luigi.parameter.TaskParameter(description='Dataset to use')
    sampling_parameters = luigi.parameter.DictParameter(description='Parameters for sampling method from GridSearch')

    def create_dataset_chain(self, dataset):
        dataset_instance = dataset(path=self.datasets_path)
        dataset_config = dataset_instance.extract_dataset_config()
        path_config = dataset_instance.extract_path_config()
        path_config['experiments_path'] = self.experiments_path
        path_config['experiment_name'] = 'exp_%s_%s' % (dataset.dataset_name, RandomForestClassifier.name)

        chain = Chain()

        chain.add(dataset, path=self.datasets_path)
        chain.add(Split, dataset_config=dataset_config, path_config=path_config,
                  ratio=self.test_train_split_ratio, stratified=self.test_train_split_stratified,
                  seed=self.test_train_split_random_seed)

        # train_test_split = chain.checkpoint()
        # train_test_split.add(FeaturesGeneration, dataset_config=dataset_config)
        # if self.sampling_task is not None:
        #     train_test_split.add(self.sampling_task, **self.sampling_parameters)

        chain.add(ExtractPartOfOutput, part_name='train')
        chain.add(CVSplit, dataset_config=dataset_config, path_config=path_config,
                  folds=self.cv_folds_count, stratified=self.cv_stratified, seed=self.cv_random_seed)

        model_template = Chain.create_task_template(self.model_task,
                                                    dataset_config=dataset_config, path_config=path_config)

        folds = []
        for i in xrange(self.cv_folds_count):
            fold_chain = chain.checkpoint()
            fold_chain.add(FoldSeparator, fold_number=i)
            fold_chain.add(FeaturesGeneration, dataset_config=dataset_config)
            fold_chain.add(self.sampling_task, dataset_config=dataset_config, path_config=path_config,
                           **self.sampling_parameters)
            fold_chain.add_from_template(model_template)
            folds.append(fold_chain)

        chain = Chain.combine_chains(folds, TrainFolds,
                                     dataset_config=dataset_config, path_config=path_config)

        chain.add(GridSearch, metric=self.metric, descending_order=self.metric_descending_order,
                  parameters_grid=self.model_task_params_grid,
                  dataset_config=dataset_config, path_config=path_config)

        # todo: somehow extract both gs parameters - for sampling method and for corresponding model
        # todo: try a trick - just repeat model gs for best sampling parameters

        # chain.add(ExtractPartOfOutput, part_name='best_parameters')
        #
        # chain = Chain.combine_chains({'parameters': chain.chain, 'data': train_test_split.chain},
        #                              ApplyParameters, model_template=model_template)

        return chain.instantiate()

    def requires(self):
        return self.create_dataset_chain(self.dataset)

    def output(self):
        # using results of final task (grid search) as output
        return self.input()


class SamplingMethodGridSearch(luigi.Task):
    sampling_pipeline = luigi.parameter.TaskParameter(description='Main pipeline class with all information')

    def _create_output_filename(self, task):
        head, tail = os.path.split(self.input()[0]['result'].path)
        # head, tail = os.path.split(self.input()[0].path)
        filename_parts = tail.split('__', 2)
        return os.path.join(head, 'gridsearch_%s__%s__%s' % (self._get_parameters_hash(), task, filename_parts[2]))

    def output(self):
        return {
            'result': luigi.LocalTarget(self._create_output_filename('result')),
            'history': luigi.LocalTarget(self._create_output_filename('history')),
            'best_parameters': luigi.LocalTarget(self._create_output_filename('best_parameters')),
            'grid_parameters': luigi.LocalTarget(self._create_output_filename('grid_parameters')),
        }

    def _generate_sampling_gs(self):
        grid = []
        param_names = self.sampling_pipeline.sampling_task_params_gird.keys()
        for param_set in itertools.product(*self.sampling_pipeline.sampling_task_params_gird.values()):
            grid.append(dict(zip(param_names, param_set)))
        return grid

    def _create_dataset_sampling_gs(self, dataset):
        grid_tasks = []
        for current_params in self._generate_sampling_gs():
            grid_tasks.append(self.sampling_pipeline(dataset=dataset, sampling_parameters=current_params))
        return grid_tasks

    def requires(self):
        # todo: generate all pipelines with all parameters for sampling method
        if self.sampling_pipeline.datasets_path is None:
            raise PipelineException('You must specify folder for datasets')
        if self.sampling_pipeline.experiments_path is None:
            raise PipelineException('You must specify folder for experiments')

        if not isinstance(self.sampling_pipeline.datasets, (list, tuple)):
            return {self.sampling_pipeline.datasets.dataset_name: self._create_dataset_sampling_gs(self.dataset)}

        requirements = {}
        for dataset in self.datasets:
            requirements[dataset.dataset_name] = self._create_dataset_sampling_gs(dataset)
        return requirements

    def run(self):
        result_dataset = {}
        for dataset in self.datasets:
            results = []
            for i, input_file in enumerate(self.input()[dataset.dataset_name]):
                with input_file['result'].open() as f:
                    result = json.load(f)
                    results.append((i, result))

            results = sorted(results, key=lambda x: (x[1]['scores'][self.sampling_pipeline.metric]['mean'],
                                                     x[1]['scores'][self.sampling_pipeline.metric]['std'],
                                                     x[1]['model_train_time']['mean']),
                             reverse=self.sampling_pipeline.metric_descending_order)

            result_dataset[dataset.dataset_name] = {
                'sampling_parameters': self._generate_sampling_gs()[results[0][0]],
                'result': results[0][1]
            }
            # todo: save all results per dataset

        with self.output()['result'].open(mode='w') as f:
            json.dump(result_dataset, f, indent=4, sort_keys=True)
        setup_permissions(self.output()['result'].path)
        # with self.output()['history'].open(mode='w') as f:
        #     json.dump(results, f, indent=4, sort_keys=True)
        # setup_permissions(self.output()['history'].path)
        # with self.output()['best_parameters'].open(mode='w') as f:
        #     json.dump(results[0]['model_parameters'], f, indent=4, sort_keys=True)
        # setup_permissions(self.output()['best_parameters'].path)


class SimplePipeline(luigi.Task):
    datasets_path = None
    experiments_path = None

    test_train_split_ratio = 0.7
    test_train_split_stratified = True
    test_train_split_random_seed = 42

    cv_folds_count = 5
    cv_stratified = True
    cv_random_seed = 42

    datasets = []
    sampling_task = None
    sampling_task_params_gird = None
    # parameters = luigi.parameter.DictParameter(description='Parameters for sampling method from GridSearch')
    model_task = None
    model_task_params_grid = None

    def create_dataset_chain(self, dataset):
        dataset_instance = dataset(path=self.datasets_path)
        dataset_config = dataset_instance.extract_dataset_config()
        path_config = dataset_instance.extract_path_config()
        path_config['experiments_path'] = self.experiments_path
        path_config['experiment_name'] = 'exp_%s_%s' % (dataset.dataset_name, RandomForestClassifier.name)

        chain = Chain()

        chain.add(dataset, path=self.datasets_path)
        chain.add(Split, dataset_config=dataset_config, path_config=path_config,
                  ratio=self.test_train_split_ratio, stratified=self.test_train_split_stratified,
                  seed=self.test_train_split_random_seed)

        train_test_split = chain.checkpoint()
        train_test_split.add(FeaturesGeneration, dataset_config=dataset_config)
        if self.sampling_task is not None:
            # todo: add sampling here, with right parameters that was found as the best ones
            train_test_split.add(self.sampling_task, tag='sampling')

        chain.add(ExtractPartOfOutput, part_name='train')
        chain.add(CVSplit, dataset_config=dataset_config, path_config=path_config,
                  folds=self.cv_folds_count, stratified=self.cv_stratified, seed=self.cv_random_seed)

        model_template = Chain.create_task_template(self.model_task,
                                                    dataset_config=dataset_config, path_config=path_config)

        folds = []
        for i in xrange(self.cv_folds_count):
            fold_chain = chain.checkpoint()
            fold_chain.add(FoldSeparator, fold_number=i)
            fold_chain.add(FeaturesGeneration, dataset_config=dataset_config)
            fold_chain.add(self.sampling_task, tag='sampling')
            fold_chain.add_from_template(model_template)
            folds.append(fold_chain)

        chain = Chain.combine_chains(folds, TrainFolds,
                                     dataset_config=dataset_config, path_config=path_config)

        chain.add(GridSearch, metric='auc', descending_order=True,
                  parameters_grid=self.model_task_params_grid,
                  dataset_config=dataset_config, path_config=path_config)

        chain.add(UpdateTagWrapper, tag='sampling')

        chain.add(GridSearch, metric='auc', descending_order=True,
                  parameters_grid=self.sampling_task_params_gird,
                  dataset_config=dataset_config, path_config=path_config)

        # todo: somehow extract both gs parameters - for sampling method and for corresponding model
        # todo: try a trick - just repeat model gs for best sampling parameters

        chain.add(ExtractPartOfOutput, part_name='best_parameters')

        chain = Chain.combine_chains({'parameters': chain.chain, 'data': train_test_split.chain},
                                     ApplyParameters, model_template=model_template)

        return chain.instantiate()

    def run(self):
        if self.datasets_path is None:
            raise PipelineException('You must specify folder for datasets')
        if self.experiments_path is None:
            raise PipelineException('You must specify folder for experiments')

        if not isinstance(self.datasets, (list, tuple)):
            return self.create_dataset_chain(self.dataset)

        requirements = []
        for dataset in self.datasets:
            requirements.append(self.create_dataset_chain(dataset))


class DatasetCheckPipeline(luigi.Task):
    # datasets_path = None
    # experiments_path = None
    # dataset = None
    datasets_path = luigi.parameter.Parameter(description='Path to dataset folder')
    experiments_path = luigi.parameter.Parameter(description='Path to experiment folder')
    dataset = luigi.parameter.TaskParameter(description='Dataset task to test')

    test_train_split_ratio = 0.7
    test_train_split_stratified = True
    test_train_split_random_seed = 42

    cv_folds_count = 5
    cv_stratified = True
    cv_random_seed = 42

    model_task = RandomForestClassifier
    model_task_params_grid = {
        'min_samples_split': [5],
        'min_samples_leaf': [3],
        'max_depth': [2, 3],
    }

    def create_dataset_chain(self, dataset):
        dataset_instance = dataset(path=self.datasets_path)
        dataset_config = dataset_instance.extract_dataset_config()
        path_config = dataset_instance.extract_path_config()
        path_config['experiments_path'] = self.experiments_path
        path_config['experiment_name'] = 'exp_%s_test' % (dataset.dataset_name,)

        chain = Chain()

        chain.add(dataset, path=self.datasets_path)
        chain.add(Split, dataset_config=dataset_config, path_config=path_config,
                  ratio=self.test_train_split_ratio, stratified=self.test_train_split_stratified,
                  seed=self.test_train_split_random_seed)

        train_test_split = chain.checkpoint()
        train_test_split.add(FeaturesGeneration, dataset_config=dataset_config)

        chain.add(ExtractPartOfOutput, part_name='train')
        chain.add(CVSplit, dataset_config=dataset_config, path_config=path_config,
                  folds=self.cv_folds_count, stratified=self.cv_stratified, seed=self.cv_random_seed)

        model_template = Chain.create_task_template(self.model_task,
                                                    dataset_config=dataset_config, path_config=path_config)

        folds = []
        for i in xrange(self.cv_folds_count):
            fold_chain = chain.checkpoint()
            fold_chain.add(FoldSeparator, fold_number=i)
            fold_chain.add(FeaturesGeneration, dataset_config=dataset_config)
            fold_chain.add_from_template(model_template)
            folds.append(fold_chain)

        chain = Chain.combine_chains(folds, TrainFolds,
                                     dataset_config=dataset_config, path_config=path_config)

        chain.add(GridSearch, metric='auc', descending_order=True,
                  parameters_grid=self.model_task_params_grid,
                  dataset_config=dataset_config, path_config=path_config)

        chain.add(ExtractPartOfOutput, part_name='best_parameters')

        chain = Chain.combine_chains({'parameters': chain.chain, 'data': train_test_split.chain},
                                     ApplyParameters, model_template=model_template)

        return chain.instantiate()

    def requires(self):
        # todo: fix this issue with logging (use conf file?)
        import logging
        logging.getLogger('luigi-interface').setLevel(logging.INFO)

        if self.datasets_path is None:
            raise PipelineException('You must specify folder for datasets')
        if self.experiments_path is None:
            raise PipelineException('You must specify folder for experiments')

        return self.create_dataset_chain(self.dataset)


def check_dataset(dataset, datasets_path='/group/research/datasets', experiments_path='/group/research/experiments'):
    check_task = DatasetCheckPipeline(dataset=dataset, datasets_path=datasets_path, experiments_path=experiments_path)
    luigi.build([check_task], local_scheduler=True)


class CheckSamplingPipeline(luigi.Task):
    datasets_path = luigi.parameter.Parameter(description='Path to dataset folder')
    experiments_path = luigi.parameter.Parameter(description='Path to experiment folder')
    dataset = luigi.parameter.TaskParameter(description='Dataset task to test')
    sampling_method = luigi.parameter.TaskParameter(description='Sampling method')
    sampling_parameters = luigi.parameter.DictParameter(description='Parameters for sampling method')

    test_train_split_ratio = 0.7
    test_train_split_stratified = True
    test_train_split_random_seed = 42

    cv_folds_count = 5
    cv_stratified = True
    cv_random_seed = 42

    model_task = RandomForestClassifier
    model_task_params_grid = {
        'min_samples_split': [5],
        'min_samples_leaf': [3],
        'max_depth': [2, 3],
    }

    def create_dataset_chain(self, dataset):
        dataset_instance = dataset(path=self.datasets_path)
        dataset_config = dataset_instance.extract_dataset_config()
        path_config = dataset_instance.extract_path_config()
        path_config['experiments_path'] = self.experiments_path
        path_config['experiment_name'] = 'exp_%s_%s_test' % (dataset.dataset_name, self.sampling_method.name)

        chain = Chain()

        chain.add(dataset, path=self.datasets_path)
        chain.add(Split, dataset_config=dataset_config, path_config=path_config,
                  ratio=self.test_train_split_ratio, stratified=self.test_train_split_stratified,
                  seed=self.test_train_split_random_seed)

        train_test_split = chain.checkpoint()
        train_test_split.add(FeaturesGeneration, dataset_config=dataset_config)
        train_test_split.add(self.sampling_method, dataset_config=dataset_config, path_config=path_config,
                             **self.sampling_parameters)

        chain.add(ExtractPartOfOutput, part_name='train')
        chain.add(CVSplit, dataset_config=dataset_config, path_config=path_config,
                  folds=self.cv_folds_count, stratified=self.cv_stratified, seed=self.cv_random_seed)

        model_template = Chain.create_task_template(self.model_task,  # n_estimators=100,
                                                    dataset_config=dataset_config, path_config=path_config)

        folds = []
        for i in xrange(self.cv_folds_count):
            fold_chain = chain.checkpoint()
            fold_chain.add(FoldSeparator, fold_number=i)
            fold_chain.add(FeaturesGeneration, dataset_config=dataset_config)
            fold_chain.add(self.sampling_method, dataset_config=dataset_config, path_config=path_config,
                           **self.sampling_parameters)
            fold_chain.add_from_template(model_template)
            folds.append(fold_chain)

        chain = Chain.combine_chains(folds, TrainFolds,
                                     dataset_config=dataset_config, path_config=path_config)

        chain.add(GridSearch, metric='auc', descending_order=True,
                  parameters_grid=self.model_task_params_grid,
                  dataset_config=dataset_config, path_config=path_config)

        chain.add(ExtractPartOfOutput, part_name='best_parameters')

        chain = Chain.combine_chains({'parameters': chain.chain, 'data': train_test_split.chain},
                                     ApplyParameters, model_template=model_template)

        return chain.instantiate()

    def requires(self):
        # todo: fix this issue with logging (use conf file?)
        import logging
        logging.getLogger('luigi-interface').setLevel(logging.INFO)

        if self.datasets_path is None:
            raise PipelineException('You must specify folder for datasets')
        if self.experiments_path is None:
            raise PipelineException('You must specify folder for experiments')

        return self.create_dataset_chain(self.dataset)


def check_sampling(sampling_method,
                   sampling_parameters={'ratio': 'auto', 'random_state': 0},
                   dataset=BostonDataset,
                   datasets_path='/group/research/datasets',
                   experiments_path='/group/research/experiments'):
    check_task = CheckSamplingPipeline(dataset=dataset,
                                       datasets_path=datasets_path, experiments_path=experiments_path,
                                       sampling_method=sampling_method, sampling_parameters=dict(sampling_parameters))
    luigi.build([check_task], local_scheduler=True)


class NewMain(luigi.Task):
    def requires(self):
        datasets_folder = 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets'
        experiments_folder = 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\experiments'
        folds_count = 5

        # todo: change way to get configs without creating dataset
        dataset = BostonDataset(path=datasets_folder)
        dataset_config = dataset.extract_dataset_config()
        path_config = dataset.extract_path_config()
        path_config['experiments_path'] = experiments_folder
        path_config['experiment_name'] = 'exp_%s_%s' % (dataset.dataset_name, RandomForestClassifier.name)

        # chain = create_task_chain(BostonDataset, path=datasets_path)
        # chain = add_task_to_chain(chain, Split, dataset_config=dataset_config, ratio=0.7, stratified=True, seed=42,
        #                           path_config=path_config)

        chain = Chain()

        chain.add(BostonDataset, path=datasets_folder)
        chain.add(Split, dataset_config=dataset_config, ratio=0.7, stratified=True, seed=42, path_config=path_config)

        train_test_split = chain.checkpoint()

        train_test_split.add(FeaturesGeneration, dataset_config=dataset_config)
        # train_test_split.add(RandomForestClassifier, dataset_config=dataset_config, path_config=path_config, n_estimators=100)

        chain.add(ExtractPartOfOutput, part_name='train')
        chain.add(CVSplit, dataset_config=dataset_config, folds=folds_count, stratified=True, seed=42,
                  path_config=path_config)

        rfc_template = Chain.create_task_template(RandomForestClassifier,
                                                  dataset_config=dataset_config, path_config=path_config,
                                                  n_estimators=100)

        folds = []
        for i in xrange(folds_count):
            fold_chain = chain.checkpoint()
            fold_chain.add(FoldSeparator, fold_number=i)
            fold_chain.add(FeaturesGeneration, dataset_config=dataset_config)
            fold_chain.add_from_template(rfc_template)
            # fold_chain.add(RandomForestClassifier, dataset_config=dataset_config, path_config=path_config,
            #                n_estimators=100)
            folds.append(fold_chain)


        chain = Chain.combine_chains(folds, TrainFolds,
                                     dataset_config=dataset_config, path_config=path_config)

        rf_param_grid = {
            'min_samples_split': [5, 10, 20, 30],
            'min_samples_leaf': [3, 5, 10],
            'max_depth': [2, 3, 5, 7],
        }

        rf_param_grid = {
            'min_samples_split': [5],
            # 'min_samples_split': [5, 10],
            'min_samples_leaf': [3],
            'max_depth': [2, 3],
            # 'max_depth': [2, 3, 5],
        }

        chain.add(GridSearch, metric='auc', descending_order=True,
                  parameters_grid=rf_param_grid,
                  dataset_config=dataset_config, path_config=path_config)

        chain.add(ExtractPartOfOutput, part_name='best_parameters')

        chain = Chain.combine_chains({'parameters': chain.chain, 'data': train_test_split.chain},
                                     ApplyParameters, model_template=rfc_template)

        return chain.instantiate()


class Main(luigi.Task):
    def requires(self):
        datasets_path = 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets'
        experiments_path = 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\experiments'
        folds_count = 5
        dataset = BostonDataset(path=datasets_path)
        dataset_config = dataset.extract_dataset_config()
        path_config = dataset.extract_path_config()
        path_config['experiments_path'] = experiments_path
        traintest_split = Split(input_data=dataset, dataset_config=dataset_config, ratio=0.7, stratified=True, seed=42,
                                path_config=path_config)
        path_config['split_folder'] = traintest_split._create_param_string()
        train_extracted = ExtractPartOfOutput(traintest_split, 'train')
        cvs = CVSplit(input_data=train_extracted, dataset_config=dataset_config,
                      folds=folds_count, stratified=True, seed=42,
                      path_config=path_config)
        folds = []
        for i in xrange(folds_count):
            fold_itself = FoldSeparator(input_data=cvs, fold_number=i)
            fold_features = FeaturesGeneration(input_data=fold_itself, dataset_config=dataset_config)
            folds.append(fold_features)

        # combined = CombineOutputs(folds)
        path_config['experiment_name'] = 'exp_%s_%s' % (dataset.dataset_name, RandomForestClassifier.name)

        # tf = TrainFolds(model=RandomForestClassifier, input_data=folds, dataset_config=dataset_config, path_config=path_config)

        rfcs = []
        for f in folds:
            rfc = RandomForestClassifier(input_data=f, dataset_config=dataset_config, path_config=path_config,
                                         n_estimators=10)
            rfcs.append(rfc)

        # rfc = RandomForestClassifier(input_data=folds[-1], dataset_config=dataset_config, path_config=path_config,
        #                              n_estimators=100)

        # tts_f = FeaturesGeneration(input_data=traintest_split, dataset_config=dataset_config)
        # rfc = RandomForestClassifier(input_data=tts_f, dataset_config=dataset_config, path_config=path_config,
        #                              n_estimators=100)
        # print rfc.get_parameters()
        # from luigi.tools import deps_tree
        # print deps_tree.print_tree(tf)
        return rfcs


if __name__ == '__main__':
    # config = {
    #     'directory': 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets'
    # }
    # task = BostonDataset(config=config)
    # task.run()

    # setting parallel workers count. doesn't work on windows because of fork implementation
    # luigi.run(local_scheduler=True, cmdline_args=['--workers=2'], main_task_cls=Main)

    # luigi.run(local_scheduler=True, main_task_cls=Main)

    # check_dataset(dataset=BostonDataset,
    #               datasets_path='C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets',
    #               experiments_path='C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\experiments')

    check_sampling(sampling_method=RandomUnderSampling,
                   dataset=BostonDataset,
                   datasets_path='C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets',
                   experiments_path='C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\experiments')

    # UNCOMMENT THIS ONE
    # luigi.run(local_scheduler=True, main_task_cls=NewMain)

    # luigi.run(local_scheduler=True, main_task_cls=BostonDataset,
    #           cmdline_args=["--path 'C:\\Users\\valeriy.ischenko\\Documents\\research\\imbalanced\\datasets'"])
