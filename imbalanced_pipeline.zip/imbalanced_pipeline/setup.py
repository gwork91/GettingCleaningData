from setuptools import setup

setup(name='imbalanced_pipeline',
      version='0.01',
      description='Pipeline code for imbalanced data project',
      author='Valeriy Ischenko',
      author_email='valeriy.ischenko@axa.com',
      packages=['imbalanced_pipeline'],
      zip_safe=False)