import pandas as pd
import numpy as np

# ++++++++++++++++++++++++++++++++++++++++++++ CATEGORICAL variable funcs ++++++++++++++++++++++++++++++++++++++++++++

# Function-1 : For CATEGORICAL variable with unique count>2 : Used by Train (Further used for dummies)

# 1. Function made to ease the variable names coming in the categorical columns and mapping them to a normal naming structure
# 2. All unique values with count>5% of total entries are assigned name using : initial column name + row number in the unique values
# 3. All unique values with count<5% of total entries are kept in same bucket : this bucket size could be lesser than 5% overall if all such entries don't sum up enough

def new_entry(row,col, prcnt_5):
    if(row['value_cnt']>prcnt_5):
        return col+"_"+str(row.name)
    else: 
        return col+"_others"

    
# Function-2 :  For CATEGORICAL variable with unique count>2 : Used by Train (Further used for dummies)

# 1. It creates a unified Data Frame for all desired categorical variables, which are to go through get_dummies and have unique value count>2, with mapping of their unique variables names to their eased names, along with the count of values, percentage of values, and the intial column name, it uses above defined 'new_entry' function to create the eased mapped names
# 2. 4 other columns are added in this 
def col_map(train,cols):
    full_mapping=pd.DataFrame()
    prcnt_5 = round(train.shape[0]*0.05,0)
    for col in cols:
        df_=pd.DataFrame(train[col].value_counts())
        df_.reset_index(level=0, inplace=True)
        df_.rename(columns={col:'value_cnt'}, inplace=True)
        df_['value_prcnt']=(df_['value_cnt']/train.shape[0])*100
        df_['mapped'] = df_.apply(lambda row : new_entry(row,col, prcnt_5) , axis=1)
        df_['column_name'] = col
        full_mapping=full_mapping.append(df_)
        del df_
    return pd.DataFrame(full_mapping)


# Function-3 : For CATEGORICAL variable with unique count>2 : Used by Train and Test (Further used for dummies)

# 1. Joins the unified dataframe created by above function with the original train and test datasets, after passing
# 2. Drops the original columns with complex values in them
# 3. Returns new dataframe with the mapped values in the categorical columns, and new name is appended with '_mapped'
def append_mapping(data, cols, cat_map_df):
    for i in range(0,len(cols)):
        data = pd.merge(data,cat_map_df[cat_map_df.column_name==cols[i]][["index","mapped"]], left_on=cols[i], right_on="index",how="left")
        data.drop(['index',cols[i]], inplace=True, axis=1)
        new_name = cols[i]+'_mapped'
        data.rename(columns={'mapped':new_name}, inplace=True)
    return data

# Function-4 : For CATEGORICAL variables with all unique counts. Used by Train and Test

# 1. Takes input Train and Test dataframes, List of features on which dummies to be created, unique value count 
# Create dummies : merge and return
def dummy_fn(data, vars_, len_type):
    data_dum = data[vars_]
    data_dum = pd.get_dummies(data_dum)
    # Selecting alternate dummied columns for features with unique value=2
    if (len_type==2):
        data_dum=data_dum.ix[:,::2]
    orig_cols = list(data.columns)
    fin_cols = [i for i in orig_cols if i not in vars_]
    data.drop(vars_, inplace=True, axis=1)
    data=data.reindex(columns=fin_cols)   
    data = pd.concat([data, data_dum], axis=1, join_axes=[data.index])
    return data


# ++++++++++++++++++++++++++++++++++++++++++++ CONTINUOUS variable funcs ++++++++++++++++++++++++++++++++++++++++++++

# Function-4 : For CONTINUOUS variable : For Train and Test dataset

# 1. Takes the dataset and the continuous variables list
# 2. Imputes the missing values with mean of the column and prints the column names which have missing values for the given data
def cnt_shortlist(data, vars_, data_type):
    df_=pd.DataFrame(data[vars_].count())
    df_.reset_index(level=0, inplace=True)
    vars_1 = list(df_['index'][(df_.iloc[:,1]<data.shape[0])])
    print(data_type,"has variables",vars_1,"with missing values")
        # Imputing by mean
    for i in range(0,len(vars_)):
        data[vars_[i]].fillna(data[vars_[i]].mean(), inplace=True)
        data[vars_[i]].apply(lambda row : round(row,2) )
        #data[vars_[i]] = round(data[vars_[i]],2)
    return data

# ++++++++++++++++++++++++++++++++++++++++++++ DATE variable funcs : NOT USED !! ++++++++++++++++++++++++++++++++++++++++++++

# Function-5 : For DATE variables : For Train and Test Datset
# FUNCTION RETURNS 00:00:00 APPENDED TO THE FINAL DATE COLUMNS IF CALLED FROM HERE, ELSE WORKING FINE

# 1. Takes the dataset, date variables list, date variables desired format list as input
# 2. converts to pandas to_datetime type
# 3. Imputes the missing NaT values with the ones which have maximum frequency in the column
def clean_date_col(data, vars_, formats_):
    for i in range(0,len(vars_)):
        data[vars_[i]] = pd.to_datetime(data[vars_[i]],  format=formats_[i], errors="coerce")
        data[vars_[i]] = data[vars_[i]].fillna( pd.to_datetime(data[vars_[i]].mode().item()))
        data[vars_[i]] = pd.to_datetime(data[vars_[i]], format=formats_[i])
    return data

# Finds the difference of max element to
def date_diff(data, vars_):
    for i in range(0,len(vars_)):
        data[vars_[i]+'_diff'] = [int(i.days) for i in (data[vars_[i]].max() - data[vars_[i]]) ]
        data.drop(vars_[i], inplace=True, axis=1)
    return data
