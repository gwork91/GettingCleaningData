import pandas as pd
import numpy as np
import sklearn as sk
import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
from sklearn.metrics import roc_curve, auc

import plotly.plotly as py
from plotly.offline import download_plotlyjs
import seaborn as sns

def get_nb_call(y_true, y_score, nb_xsell):
    df = pd.DataFrame({'y_true':y_true, 'y_score':y_score})
    sort_df = df.sort_values(by='y_score', ascending=False).reset_index(drop=True)
    sort_df['cum'] = np.cumsum(sort_df.y_true)
    sort_df = sort_df.reset_index()
    nb_call = sort_df.loc[sort_df.cum == nb_xsell, 'index'].min() +1
    
    return nb_call

def get_nb_calls(y_true, y_score, nb_xsells):
    nb_calls = pd.DataFrame([], columns=['Desired_Defaulters','Total_Contacts', 'Total_Population', 'Total_Defaulters', 
                            'Default_Rate','Prcnt_of_Defaulters_found', 'Prcnt_of_Population', 'Lift'])
    nb_calls['Desired_Defaulters'] = nb_xsells
    nb_calls['Total_Contacts'] = nb_calls['Desired_Defaulters'].apply(lambda x : get_nb_call(y_true, y_score,x))
    nb_calls['Total_Population'] = len(y_true)
    nb_calls['Total_Defaulters'] = y_true.sum()
    nb_calls['Default_Rate'] = (nb_calls.Desired_Defaulters*1.0) / nb_calls.Total_Contacts
    nb_calls['Prcnt_of_Defaulters_found'] = (nb_calls.Desired_Defaulters *1.0) / nb_calls.Total_Defaulters
    nb_calls['Prcnt_of_Population'] = (nb_calls.Total_Contacts*1.0) / nb_calls.Total_Population
    nb_calls['Lift'] = nb_calls.Prcnt_of_Defaulters_found / nb_calls.Prcnt_of_Population
    return nb_calls


def model_eval(clf, test_x, test_y):
    y_score = clf.predict_proba(test_x)[:, 1]
    y_true = test_y
    
    # Start to Draw Result
    fig = plt.figure(figsize=(6,12))
    fig.subplots_adjust(bottom=-0.5, left=-0.5, top = 0.5, right=1.5)
    
    # Compute ROC curve and area the curve
    fpr, tpr, thresholds = sk.metrics.roc_curve(y_true, y_score)
    roc_auc = sk.metrics.auc(fpr, tpr)
    plt.subplot(2,2,1)
    plt.plot(fpr, tpr, label='ROC  (area = %0.2f)' % ( roc_auc))
    
    #compute lift at 10%
    sorted_proba = np.array(list(reversed(np.argsort(y_score))))
    length = len(y_score)
    centile = length/100
    positives = y_true.sum()
    lift = [0]
    for q in xrange(1,101):
        if q == 100:
            tp = (np.array(y_true)[sorted_proba[(q-1)*length/100:length]]).sum()
        else:
            tp = (np.array(y_true)[sorted_proba[(q-1)*length/100:q*length/100]]).sum()
        lift.append(lift[q-1]+100*tp/float(positives))
    quantiles = range(0,101)
    plt.subplot(2,2,2)
    plt.plot(quantiles, lift, label='Lift at 10 percent = %0.2f' %(lift[10]/10.))
    print (' AUC: %f, lift at 10 percent: %f'%( roc_auc, lift[10]/10.))
    
    # Plot calibration plots
    fraction_of_positives, mean_predicted_value = calibration_curve(y_true, y_score, n_bins=20)
    plt.subplot(2,2,3)
    plt.plot(mean_predicted_value, fraction_of_positives, "s-", label="Result")
    
    # Plot predict distribution   
    plt.subplot(2,2,4)
    plt.hist(y_score, range=(0, 1), bins=100, label="Result" , histtype="step", lw=2)
    
    # Calculate nb calls to make
    all_xsell = positives
    nb_xsells = [100, 200, 500, 1000, 2000, 3000, 5000, 6000, 7000, all_xsell]
    nb_calls = get_nb_calls(y_true, y_score, nb_xsells)
    
    score_of_10_best_perc = np.percentile(y_score, 90)
    
    plt.subplot(2,2,1)
    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6))
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC', fontsize = 14)
    plt.grid(True)
    plt.legend(loc="lower right")

    plt.subplot(2,2,2)
    plt.plot([0, 100], [0, 100], 'k--',color=(0.6, 0.6, 0.6))
    plt.xlim([-5, 105])
    plt.ylim([-5, 105])
    plt.xlabel('Percentage of population')
    plt.ylabel('Cumulative gain')
    plt.title('Lift', fontsize = 14)
    plt.grid(True)
    plt.legend(loc="lower right")

    plt.subplot(2,2,3)
    plt.plot([0, 1], [0, 1], "k--", label="Perfectly calibrated")
    plt.plot([score_of_10_best_perc, score_of_10_best_perc], [0, 1], "r--")
    plt.ylabel("Fraction of positives")
    plt.xlabel("Predicted value")
    plt.ylim([-0.05, 1.05])
    plt.legend(loc="lower right")
    plt.title('Calibration plots  (reliability curve)')
    plt.grid(True)

    plt.subplot(2,2,4)
    plt.xlabel("Predicted value")
    plt.ylabel("Count")
    plt.legend(loc="upper right", ncol=2)
    plt.grid(True)

    plt.show()
    
    return nb_calls


def draw_feature_importance(fea_imp_df, nb, imp_col):
    fea_imp_df = fea_imp_df.sort_values(imp_col).reset_index(drop=True)
    fea_imp_df = fea_imp_df[-1*nb:].reset_index(drop=True)

    plt.figure(figsize=(10, nb*0.3))
    plt.title("Top %d Most Important Features"%nb)
    plt.barh(fea_imp_df.index, fea_imp_df[imp_col], color='#348ABD', align="center", lw='2', edgecolor='#348ABD', alpha=0.6)
    plt.yticks(fea_imp_df.index, fea_imp_df['features'], fontsize=12,)
    plt.ylim([-1, nb])
    plt.xlim([0, fea_imp_df[imp_col].max()*1.1])
    plt.show()