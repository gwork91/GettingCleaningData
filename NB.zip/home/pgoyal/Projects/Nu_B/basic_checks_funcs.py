import pandas as pd
import numpy as np

# Function : Used by both Train and Test
# 1. Summarize the information for columns which have missing values
# 2. Removes the columns with more than 25% missing values from consideration
# 3. Returns a list of column which are to be considered finally
# 4. Returns a list of column which are to be imputed
def get_missing_info(data_name, data, cols):
    print('Total records in ', data_name ,'%d\n'%(data.shape[0]))
    i= 0
    new_col = []
    imputed_col=[]
    for col in cols:
        if(data[data[col].isnull()].shape[0]!=0):
            i = i+1
            print('-- Column : %s --'%col)
            missin_cnt = data[data[col].isnull()].shape[0]
            print('Missing Count : %d'% (missin_cnt) )
            missing_pcnt = data[data[col].isnull()].shape[0]*100.0/data.shape[0]
            print('Missing Percent: %.3f\n'%(missing_pcnt))
            
            if(missing_pcnt<=25.0) :             # KEEPING the columns ONLY WITH <=25% missing values
                new_col.append(col)
                imputed_col.append(col)
        else:
            new_col.append(col)
    print('Total number of columns with missing value in',data_name ,':%d'%i) 
    return new_col, imputed_col



